export const countries = [
  ['AR','Argentina','ARS'], ['BO','Bolivia','BOB'], ['BR','Brasil','BRL'],
  ['CL','Chile','CLP'], ['CO','Colombia','COP'], ['CR','Costa Rica','CRC'],
  ['CU','Cuba','CUP'], ['EC','Ecuador','USD'], ['SV','El Salvador','USD'],
  ['GT','Guatemala','GTQ'], ['HT','Haití','HTG'], ['HN','Honduras','HNL'],
  ['MX','México','MXN'], ['NI','Nicaragua','NIO'], ['PA','Panamá','PAB'],
  ['PY','Paraguay','PYG'], ['PE','Perú','PEN'], ['DO','República Dominicana','DOP'],
  ['UY','Uruguay','UYU'], ['VE','Venezuela','VES']
];
export function calculate({country, current, desired, months, currency, output, rate = 1}) {
  const selected = countries.find(([code]) => code === country);
  if (!selected) throw new Error('Elegí un país de LATAM.');
  if (![current, desired, months].every(v => typeof v === 'number' && Number.isFinite(v) && v >= 0)) throw new Error('Ingresá importes y meses válidos, iguales o mayores que cero.');
  if (![currency, output].every(c => [selected[2], 'USD'].includes(c))) throw new Error('Elegí la moneda local o USD.');
  if (currency !== output && (!Number.isFinite(rate) || rate <= 0)) throw new Error('Ingresá un tipo de cambio mayor que cero.');
  const factor = currency === output ? 1 : currency === 'USD' ? rate : 1 / rate;
  const gap = Math.max(0, desired - current) * factor;
  const opportunity = gap * months;
  if (![gap, opportunity, current * factor, desired * factor].every(Number.isFinite)) throw new Error('Los importes ingresados son demasiado grandes.');
  return { gap, opportunity, current: current * factor, desired: desired * factor, currency: output };
}
