import {salaryReferences,referenceSource} from './salary-data.js';
import {roleKey} from './matching.js';
import {validateFx} from './fx.js';
export function compareRegional({referenceId,current,months,basis,fx,rows=salaryReferences,now=Date.now()}) {
  if(basis!=='gross')return {available:false,reason:'Las encuestas publican sueldos brutos; no se comparan con netos.'};
  const ref=rows.find(r=>r.id===referenceId);if(!ref)return {available:false,reason:'Elegí una referencia comparable para tu puesto.'};
  validateFx(fx,now);
  if(![current,months].every(v=>Number.isFinite(v)&&v>=0))throw new Error('Importes o meses inválidos.');
  const sectorKey = row => row.sector || (row.sourceId === 'michael-page-co-2026' ? row.page === 17 ? 'Finanzas' : 'Recursos Humanos' : '');
  const comparable=rows.filter(r=>r.basis==='gross'&&roleKey(r.role)===roleKey(ref.role)&&sectorKey(r)===sectorKey(ref));
  const countries=[];
  for(const code of ['AR','CO','MX']) {
    const group=comparable.filter(r=>r.country===code);if(!group.length)continue;
    const rates=group.map(r=>fx.rates[r.currency]);if(rates.some(x=>!Number.isFinite(x)||x<=0))throw new Error('Falta cotización para una referencia.');
    const low=group.reduce((sum,r,i)=>sum+(r.low??r.amount)/rates[i],0)/group.length;
    const high=group.reduce((sum,r,i)=>sum+(r.high??r.amount)/rates[i],0)/group.length;
    countries.push({country:code,low,high,midpoint:(low+high)/2,variants:group.length,references:group.map(r=>({role:r.role,page:r.page,low:r.low??r.amount,high:r.high??r.amount,currency:r.currency,source:referenceSource(r)}))});
  }
  const low=countries.reduce((s,r)=>s+r.low,0)/countries.length,high=countries.reduce((s,r)=>s+r.high,0)/countries.length;
  const amount=countries.reduce((s,r)=>s+r.midpoint,0)/countries.length;
  const gapLow=Math.max(0,low-current),gapHigh=Math.max(0,high-current);
  const opportunityLow=gapLow*months,opportunityHigh=gapHigh*months;
  if(![low,high,amount,gapLow,gapHigh,opportunityLow,opportunityHigh].every(Number.isFinite))throw new Error('Importes demasiado grandes.');
  const missing=['AR','CO','MX'].filter(c=>!countries.some(r=>r.country===c));
  return {available:true,kind:'range',regional:true,low,high,amount,gapLow,gapHigh,opportunityLow,opportunityHigh,countries,missing,fx,reference:ref,source:{publisher:'Referencias de mercado comparables',title:`${countries.length===3?'Promedio de tres países':'Referencia parcial'} · ${countries.map(r=>r.country).join(', ')}`,scope:'USD brutos mensuales',published:'Ediciones de las fuentes indicadas',consulted:fx.updatedAt,url:null,methodology:'Promedio simple: primero se promedian las variantes comparables dentro de cada país; luego cada país tiene el mismo peso. El valor central es el promedio de los puntos medios, no una mediana de encuesta. No equivale al promedio salarial de LATAM. '+(missing.length?`Faltan referencias comparables de ${missing.join(', ')}. No es un promedio de tres países.`:'Se incluyen Argentina, Colombia y México.')}};
}
