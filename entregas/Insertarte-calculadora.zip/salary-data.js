import { argentinaReportReferences } from './argentina-data.js';
import { mexicoPrintedReferences } from './mexico-data.js';
import { colombiaReferences } from './colombia-data.js';
// Referencias con sus fuentes y alcances; no se infieren medianas.
export const salarySource = Object.freeze({
  publisher: 'Randstad Argentina',
  title: 'Vivir y trabajar en Montevideo, Santiago o Buenos Aires: comparativa de salarios y costo de vida',
  url: 'https://www.randstad.com.ar/quienes-somos/press-releases/vivir-trabajar-montevideo-santiago-buenos-aires-comparativa-salarios/',
  published: '2026-08-05',
  consulted: '2026-10-23',
  scope: 'Buenos Aires · nivel inicial · sueldo bruto',
  methodology: 'Relevamiento de referencias iniciales publicado por Randstad; no se informa tamaño de muestra por puesto. No representa una oferta, una mediana ni un rango garantizado.'
});
const argentinaReferences = Object.freeze([
  { id: 'industrial-entry', role: 'Operario industrial · inicial', amount: 1500000 },
  { id: 'administrative-entry', role: 'Empleado administrativo · inicial', amount: 1800000 },
  { id: 'programmer-junior', role: 'Programador · junior', amount: 1800000 }
].map(row => Object.freeze({ ...row, country: 'AR', currency: 'ARS', basis: 'gross' })));

export const colombiaSource = Object.freeze({
  publisher: 'Michael Page Colombia', title: 'Guía Salarial 2026 · Colombia',
  published: 'Edición 2026; fecha exacta no indicada', consulted: '2026-10-25',
  url: null, document: 'michael-page-colombia-2026.pdf',
  methodology: 'Rangos brutos mensuales publicados en millones de COP, convertidos a COP. No son medianas ni garantizan una oferta. Se conserva la segmentación por facturación; no se informa muestra por puesto en estas tablas.'
});
export const mexicoSource = Object.freeze({
  publisher: 'Michael Page México', title: 'Guía Salarial 2027 · México',
  published: 'Edición 2027; fecha exacta no indicada', consulted: '2026-10-25',
  url: null, document: 'michael-page-mexico-2027.pdf',
  methodology: 'Sueldos brutos mensuales, sin variable, acciones ni otros beneficios. Ante la inconsistencia de escala del PDF, esta calculadora interpreta las cifras de tabla como MXN mensuales sin multiplicar por mil. Se conserva la región. La columna Med no se presenta como mediana; se usan mínimo y máximo. No garantiza una oferta.'
});
const mexicoReferences = mexicoPrintedReferences.map(row => Object.freeze({
  id:row.id, role:`${row.role} · ${row.regionPrinted}`, country:'MX', currency:'MXN', basis:'gross',
  low:row.minimumPrinted, high:row.maximumPrinted, page:row.page, sourceId:row.sourceId,
  scope:`México · ${row.sector} · ${row.regionPrinted}`,
  region:row.regionPrinted, sector:row.sector, unitMultiplier:1, unitConfirmation:'user'
}));
export const argentinaReportSource = Object.freeze({
  publisher:'Randstad Argentina',title:'Reporte Salarial · Julio 2026 · Argentina',
  published:'Julio de 2026',observed:'Valores completados al 30 de junio de 2026',consulted:'2026-10-26',
  url:null,document:'randstad-argentina-julio-2026.pdf',
  methodology:'ARS brutos mensuales, sin adicionales ni comisiones. Las tablas indican posición Semi Senior y valores completados al 30 de junio de 2026. Se conservan industria y región. Los rangos son mínimos y máximos publicados, no percentiles ni medianas.'
});
export const salaryReferences = Object.freeze([...argentinaReferences, ...argentinaReportReferences.map(Object.freeze), ...colombiaReferences.map(Object.freeze), ...mexicoReferences]);
export function referenceSource(reference) {
  if (reference.sourceId === 'randstad-ar-2026-julio') return {...argentinaReportSource,scope:reference.scope,page:reference.page};
  if (reference.sourceId === 'michael-page-mx-2027') return {...mexicoSource, scope:reference.scope, page:reference.page};
  return reference.sourceId === 'michael-page-co-2026'
    ? { ...colombiaSource, scope: reference.scope, page: reference.page }
    : salarySource;
}
