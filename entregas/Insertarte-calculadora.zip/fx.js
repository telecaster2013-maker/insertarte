import { fxSnapshot } from './fx-snapshot.js';
export function validateFx(data,now=Date.now()) {
  if(data.base!=='USD'||!Number.isFinite(data.updatedUnix)||now-data.updatedUnix*1000>7*86400000||data.updatedUnix*1000-now>86400000)throw new Error('La cotización automática está vencida o no es válida.');
  for(const currency of ['ARS','COP','MXN'])if(!Number.isFinite(data.rates?.[currency])||data.rates[currency]<=0)throw new Error('Falta una cotización válida.');
  return data;
}
export async function loadFx() {
  try {
    const response=await fetch(fxSnapshot.url,{signal:AbortSignal.timeout(5000)});if(!response.ok)throw new Error('No disponible');
    const d=await response.json();if(d.result!=='success'||d.base_code!=='USD')throw new Error('Formato inválido');
    return {...validateFx({...fxSnapshot,rates:d.rates,updatedAt:d.time_last_update_utc,updatedUnix:d.time_last_update_unix}),origin:'actualizada por API'};
  } catch {
    return {...validateFx(fxSnapshot),origin:'última cotización guardada; no se pudo actualizar'};
  }
}
