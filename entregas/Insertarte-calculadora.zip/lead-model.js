import {fallbackMarket} from './fallback-market.js';
import {salaryReferences} from './salary-data.js';
import {searchRoles,roleKey,roleTokens} from './matching.js';
import {compareRegional} from './regional.js';
import {countries} from './calculator.js';
export const WHATSAPP_NUMBER='541153324278';
export function levelOf(role) {
 const tokens=roleTokens(role);
 if(tokens.includes('director')||tokens.includes('cfo')||tokens.includes('ceo'))return 'direction';
 if(tokens.includes('gerente'))return 'management';
 if(tokens.some(t=>/^jef|^coordin|^lider/.test(t)))return 'lead';
 if(tokens.some(t=>/^junior|^inicial/.test(t)))return 'entry';
 return 'professional';
}
function sectorOf(row){return row.sector||(row.sourceId==='michael-page-co-2026'?row.page===17?'Finanzas':'Recursos Humanos':'');}
export function suggestions(query,level='',rows=salaryReferences){
 if(query.trim().length<2)return [];
 const grouped=new Map();
 for(const r of searchRoles(query,rows)){
  if(level&&levelOf(r.role)!==level)continue;
  const key=roleKey(r.role)+'|'+sectorOf(r);
  if(!grouped.has(key))grouped.set(key,{id:r.id,title:r.role.split('·')[0].trim(),sector:sectorOf(r),level:levelOf(r.role),key});
 }
 return [...grouped.values()].slice(0,8);
}
export function estimateSalary({role,referenceId,level,country,salary,currency,output,fx,rows=salaryReferences,now=Date.now()}) {
 if(!['entry','professional','lead','management','direction'].includes(level))throw new Error('Elegí tu nivel de responsabilidad.');
 if(!Number.isFinite(salary)||salary<0)throw new Error('Ingresá un sueldo mensual válido.');
 if(country!=='regional'&&!countries.some(c=>c[0]===country))throw new Error('Elegí un mercado de LATAM.');
 const allowed=new Set(['USD',...countries.map(c=>c[2])]);
 if(!allowed.has(currency)||!allowed.has(output))throw new Error('Elegí una moneda local de LATAM o USD.');
 const rate=currency==='USD'?1:fx?.rates?.[currency],factor=output==='USD'?1:fx?.rates?.[output];
 if(!Number.isFinite(rate)||rate<=0||!Number.isFinite(factor)||factor<=0)throw new Error('No pudimos obtener una cotización para esa moneda. Intentá nuevamente.');
 let ref=rows.find(r=>r.id===referenceId);
 if(ref&&levelOf(ref.role)!==level)ref=null;
 if(!ref){const matches=suggestions(role,level,rows);if(matches.length===1)ref=rows.find(r=>r.id===matches[0].id);}
 const regional=country==='regional'||currency==='USD'||output==='USD';
 const eligible=rows.filter(r=>regional||r.country===country);
 const compatible=ref?eligible.find(r=>roleKey(r.role)===roleKey(ref.role)&&sectorOf(r)===sectorOf(ref)):null;
 const broad=!compatible;
 const market=compatible
   ? compareRegional({referenceId:compatible.id,current:salary/rate,months:1,basis:'gross',fx,rows:eligible,now})
   : fallbackMarket({level,levelOf,country,regional,fx,rows,now});
 if(!market.available)return market;
 const current=salary/rate*factor,estimated=market.amount*factor,low=market.low*factor,high=market.high*factor;
 const gap=Math.max(0,estimated-current),annual=gap*12;
 if(![current,estimated,low,high,gap,annual].every(Number.isFinite))throw new Error('El importe es demasiado grande. Revisalo.');
 return {available:true,role:broad?role:ref.role.split('·')[0].trim(),basis:broad?'level-estimate':'matched-role',explanation:broad?market.source.methodology:'Referencia de un puesto igual o similar del mismo nivel.',current,estimated,low,high,gap,annual,currency:output,coverage:market.countries.length,missing:market.missing,regional:broad?market.regional:regional,position:current<low?'below':current>high?'above':'within',market};
}
export function whatsappLink({result,role,salary,currency,country}) {
 const fmt=(v,c)=>c+' '+new Intl.NumberFormat('es-AR',{maximumFractionDigits:0}).format(v);
 const message=result.available
  ? `Hola, hice el chequeo salarial de Insertarte. Trabajo como ${result.role}, mi sueldo es ${fmt(salary,currency)} por mes y la ${result.basis==='level-estimate'?'estimación orientativa por nivel':'estimación de referencia'} fue ${fmt(result.estimated,result.currency)}. Quiero conversar sobre mi próximo paso y hacer mi diagnóstico.`
  : `Hola, hice el chequeo salarial de Insertarte. Trabajo como ${role}, gano ${fmt(salary,currency)} por mes y no encontré una referencia comparable. Quiero conversar sobre mi próximo paso y hacer mi diagnóstico.`;
 return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}
