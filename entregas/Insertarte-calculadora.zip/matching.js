export function roleTokens(value) {
  const text=value.split('·')[0].normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\([dn]\)/g,'');
  return text.split(/[^a-z0-9]+/).filter(t=>t&&!['de','del','y','en','a','la','el'].includes(t)).map(t=>{
    if (/^geren[ct]/.test(t)) return 'gerente';
    if (/^administr/.test(t)) return 'administracion';
    if (/^financ/.test(t)) return 'finanzas';
    if (/^direccion|^director/.test(t)) return 'director';
    if (/^biling/.test(t)) return 'bilingue';
    return t;
  });
}
export function roleKey(role) { return [...new Set(roleTokens(role))].sort().join(' '); }
export function searchRoles(query,rows) {
  const tokens=roleTokens(query);if(!tokens.length)return rows;
  return rows.filter(row=>{const available=roleTokens(row.role);return tokens.every(t=>available.some(word=>word.startsWith(t)));});
}
