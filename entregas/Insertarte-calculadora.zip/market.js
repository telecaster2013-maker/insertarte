import { salaryReferences, referenceSource } from './salary-data.js';
export function compareMarket({ referenceId, targetCountry, basis, confirmedScope, current, currency, output, rate, months }) {
  const reference = salaryReferences.find(row => row.id === referenceId);
  if (!reference) return { available: false, reason: 'No seleccionaste una referencia publicada.' };
  if (targetCountry !== reference.country) return { available: false, reason: 'La referencia no corresponde al país del empleo buscado. No se extrapola a otros países.' };
  if (basis !== reference.basis) return { available: false, reason: 'La fuente publica sueldos brutos. No es comparable con ingresos netos.' };
  if (!confirmedScope) return { available: false, reason: 'Confirmá que el puesto y el alcance indicado corresponden a tu búsqueda.' };
  if (![reference.currency, 'USD'].includes(currency) || ![reference.currency, 'USD'].includes(output)) return { available: false, reason: `Esta comparación admite ${reference.currency} o USD. Falta una conversión verificable para tu moneda de origen.` };
  if (![current, months].every(value => Number.isFinite(value) && value >= 0)) throw new Error('Ingresá importes y meses válidos.');
  if ((currency === 'USD' || output === 'USD') && (!Number.isFinite(rate) || rate <= 0)) throw new Error(`Para comparar con la referencia, ingresá cuántos ${reference.currency} equivale 1 USD.`);
  const currentARS = currency === 'USD' ? current * rate : current;
  const divisor = output === 'USD' ? rate : 1;
  if (reference.low !== undefined) {
    const low = reference.low / divisor, high = reference.high / divisor;
    const gapLow = Math.max(0, reference.low - currentARS) / divisor;
    const gapHigh = Math.max(0, reference.high - currentARS) / divisor;
    const opportunityLow = gapLow * months, opportunityHigh = gapHigh * months;
    if (![currentARS, low, high, gapLow, gapHigh, opportunityLow, opportunityHigh].every(Number.isFinite)) throw new Error('Los importes ingresados son demasiado grandes.');
    return {available:true, kind:'range', low, high, gapLow, gapHigh, opportunityLow, opportunityHigh, reference, source:referenceSource(reference)};
  }
  const amount = reference.amount / divisor;
  const gap = Math.max(0, reference.amount - currentARS) / divisor;
  const opportunity = gap * months;
  if (![currentARS, amount, gap, opportunity].every(Number.isFinite)) throw new Error('Los importes ingresados son demasiado grandes.');
  return { available: true, amount, gap, opportunity, reference, source: referenceSource(reference) };
}

export function marketValue(market, key, money) {
  if (market.kind !== 'range') return money(market[key]);
  const keys = { amount:['low','high'], gap:['gapLow','gapHigh'], opportunity:['opportunityLow','opportunityHigh'] }[key];
  return `${money(market[keys[0]])} – ${money(market[keys[1]])}`;
}
