export function setupFlow() {
  const form = document.querySelector('#calculator');
  const steps = [...form.querySelectorAll('.form-step')];
  const indicators = [...document.querySelectorAll('.stepper li')];
  const back = document.querySelector('#step-back');
  const next = document.querySelector('#step-next');
  const submit = form.querySelector('[type=submit]');
  let current = 0;
  function show(index, focus = true) {
    current = index;
    steps.forEach((step, i) => { step.hidden = i !== index; });
    indicators.forEach((item, i) => {
      item.classList.toggle('active', i === index);
      item.classList.toggle('complete', i < index);
      if (i === index) item.setAttribute('aria-current', 'step'); else item.removeAttribute('aria-current');
    });
    document.querySelector('#step-progress').style.width = `${(index + 1) / steps.length * 100}%`;
    back.hidden = index === 0; next.hidden = index === steps.length - 1; submit.hidden = !next.hidden;
    if (focus) {
      const title = steps[index].querySelector('h2'); title.tabIndex = -1; title.focus({preventScroll:true});
      if (window.innerWidth < 760) document.querySelector('.form-card').scrollIntoView({behavior:'instant',block:'start'});
    }
  }
  function invalid(step) { return [...step.querySelectorAll('input,select')].find(input => !input.disabled && !input.checkValidity()); }
  function advance() {
    const input = invalid(steps[current]);
    if (input) { input.reportValidity(); return; }
    show(Math.min(current + 1, steps.length - 1));
  }
  next.addEventListener('click', advance);
  back.addEventListener('click', () => show(Math.max(0,current - 1)));
  form.addEventListener('submit', event => {
    if (current < steps.length - 1) { event.preventDefault(); event.stopImmediatePropagation(); advance(); return; }
    for (let i = 0; i < steps.length; i++) {
      const input = invalid(steps[i]);
      if (input) { event.preventDefault(); event.stopImmediatePropagation(); show(i); input.reportValidity(); return; }
    }
  }, true);
  show(0,false);
}
