import { searchRoles, roleKey } from './matching.js';
import { loadFx } from './fx.js';
import { compareRegional } from './regional.js';
import { setupFlow } from './flow.js';
import { countries, calculate } from './calculator.js';
import { salaryReferences } from './salary-data.js';
import { compareMarket, marketValue } from './market.js';
import { buildReport } from './report.js';
let activeFx = null;
let fxFailure = '';
const form = document.querySelector('form');
const field = name => form.elements.namedItem(name);
for (const name of ['country', 'targetCountry']) {
  for (const [code, label] of countries) field(name).add(new Option(label, code));
}
const searchReferences = document.querySelector('#reference-search');
function filterReferences() {
  const selected = salaryReferences.find(row => row.id === field('reference').value);
  const normalize = value => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const words = normalize(searchReferences.value).trim().split(/\s+/).filter(Boolean);
  const regional = field('output').value === 'USD' || field('currency').value === 'USD';
  const countryRows = salaryReferences.filter(row => regional || row.country === field('targetCountry').value);
  const matches = searchRoles(searchReferences.value, countryRows);
  field('reference').replaceChildren(new Option('Solo calcular mi objetivo personal', ''));
  const visibleMatches = words.length ? matches.slice(0, 100) : [];
  for (const row of visibleMatches) field('reference').add(new Option(`${row.country} · ${row.role}`, row.id));
  document.querySelector('#reference-count').textContent = !words.length ? 'Escribí el puesto para buscar en las guías.' : `${matches.length} referencias encontradas${matches.length > 100 ? '; mostramos las primeras 100. Afiná por puesto, región o industria.' : '.'}`;
  if (selected && (regional || selected.country === field('targetCountry').value)) {
    if (!matches.some(row => row.id === selected.id)) field('reference').add(new Option(selected.role, selected.id));
    field('reference').value = selected.id;
  } else if (selected) {
    field('role').readOnly = false; field('role').value = ''; field('confirmedScope').checked = false;
  }
  if (!matches.length) {
    const option = new Option(countryRows.length ? 'No hay coincidencias para esa búsqueda' : 'Todavía no hay referencias para este país', ''); option.disabled = true; field('reference').add(option);
  }
  updateExchange();
}
searchReferences.addEventListener('input', filterReferences);
field('role').addEventListener('input', () => { field('reference').value = ''; field('confirmedScope').checked = false; searchReferences.value = field('role').value; filterReferences(); });
field('targetCountry').addEventListener('change', () => { searchReferences.value = ''; filterReferences(); });
let hasResult = false;
function resetResult() {
  if (!hasResult) return;
  document.querySelector('#results').replaceChildren(Object.assign(document.createElement('p'), { className: 'updated-hint', textContent: 'Cuando estés listo, calculá tu brecha con los datos actuales.' }));
  document.querySelector('#error').textContent = '';
}
function setCurrencies() {
  const local = countries.find(([c]) => c === field('country').value)[2];
  for (const name of ['currency', 'output']) {
    field(name).replaceChildren();
    for (const c of new Set([local, 'USD'])) field(name).add(new Option(c, c));
  }
  field('rate').value = ''; field('rateDate').value = ''; field('rateSource').value = '';
  updateExchange();
}
function exchangeUnit() {
  const ref = salaryReferences.find(row => row.id === field('reference').value);
  if (ref && field('currency').value === 'USD' && field('output').value === 'USD') return ref.currency;
  return countries.find(([code]) => code === field('country').value)[2];
}
function updateExchange() {
  document.querySelector('#exchange').hidden = true;
  for (const name of ['rate', 'rateDate', 'rateSource']) { field(name).required = false; field(name).disabled = true; }
  if (activeFx) {
    field('rate').value = activeFx.rates[exchangeUnit()] || '';
    field('rateDate').value = new Date(activeFx.updatedUnix * 1000).toISOString().slice(0,10);
    field('rateSource').value = activeFx.provider;
  }
  document.querySelector('#fx-status').textContent = activeFx ? `Cambio automático · ${activeFx.provider} · ${new Date(activeFx.updatedUnix * 1000).toLocaleDateString('es-AR')} · ${activeFx.origin}` : fxFailure || 'Cargando cotizaciones automáticas…';
}
field('country').addEventListener('change', setCurrencies);
for (const name of ['currency', 'output', 'targetCountry', 'basis', 'confirmedScope']) field(name).addEventListener('change', () => { if (name === 'currency' && field('currency').value === 'USD') field('output').value = 'USD'; updateExchange(); if (['currency','output'].includes(name)) filterReferences(); });
field('reference').addEventListener('change', () => {
  const reference = salaryReferences.find(row => row.id === field('reference').value);
  field('role').readOnly = false;
  field('role').value = reference ? reference.role : '';
  field('confirmedScope').checked = false;
  updateExchange();
});
field('employment').addEventListener('change', () => {
  const unemployed = field('employment').value === 'unemployed';
  field('current').readOnly = unemployed;
  field('current').value = unemployed ? '0' : '';
});
form.addEventListener('input', resetResult);
form.addEventListener('change', resetResult);
form.addEventListener('submit', async event => {
  event.preventDefault();
  try {
    if (!activeFx) { try { activeFx = await fxReady; } catch { /* Reportar más abajo si se necesita cambio. */ } }
    const regionalMode = field('output').value === 'USD' || field('currency').value === 'USD';
    if ((regionalMode || field('currency').value !== field('output').value) && !activeFx) throw new Error(fxFailure || 'No se pudo obtener una cotización válida. Intentá de nuevo con conexión.');
    if (regionalMode) field('output').value = 'USD';
    const unit = countries.find(([code]) => code === field('country').value)[2];
    const conversionRate = activeFx?.rates[unit];
    const result = calculate({ country: field('country').value, current: Number(field('current').value), desired: Number(field('desired').value), months: Number(field('months').value), currency: field('currency').value, output: field('output').value, rate: conversionRate });
    let referenceId = field('reference').value;
    if (!referenceId && field('role').value.trim()) {
      const candidates = searchRoles(field('role').value, salaryReferences.filter(row => regionalMode || row.country === field('targetCountry').value));
      if (new Set(candidates.map(row => roleKey(row.role) + '|' + (row.sector || (row.sourceId === 'michael-page-co-2026' ? row.page === 17 ? 'Finanzas' : 'Recursos Humanos' : '')))).size === 1 && candidates.length && (regionalMode || candidates.length === 1 || candidates.every(row => row.low === candidates[0].low && row.high === candidates[0].high))) referenceId = candidates[0].id;
    }
    const selectedRef = salaryReferences.find(row => row.id === referenceId);
    const market = regionalMode
      ? compareRegional({referenceId, current:result.current, months:Number(field('months').value), basis:field('basis').value, fx:activeFx})
      : compareMarket({ referenceId, targetCountry:field('targetCountry').value,basis:field('basis').value,confirmedScope:field('confirmedScope').checked || (!field('reference').value && Boolean(referenceId)),current:Number(field('current').value),currency:field('currency').value,output:field('output').value,rate:activeFx?.rates[selectedRef?.currency],months:Number(field('months').value) });
    const money = value => new Intl.NumberFormat('es-AR', { style: 'currency', currency: result.currency, maximumFractionDigits: 2 }).format(value) + ` ${result.currency}`;
    const box = document.querySelector('#results'); box.replaceChildren(); hasResult = true;
    const add = (tag, text, cls) => { const el = document.createElement(tag); el.textContent = text; if (cls) el.className = cls; box.append(el); };
    add('p', 'TU OPORTUNIDAD ESTIMADA', 'eyebrow');
    add('h2', money(result.opportunity), 'amount');
    add('p', `Durante ${field('months').value} meses de búsqueda, a valores actuales.`);
    add('h3', `${money(result.gap)} / mes`);
    add('p', 'Es la brecha entre tu ingreso actual y tu objetivo personal.');
    const chart = document.createElement('div'); chart.className = 'salary-chart';
    const ceiling = Math.max(result.current, result.desired, 1);
    for (const [label, value] of [['Hoy', result.current], ['Tu objetivo', result.desired]]) {
      const row = document.createElement('div'); row.className = 'salary-chart-row';
      const caption = document.createElement('div'); const name = document.createElement('span'); name.textContent = label;
      const amount = document.createElement('strong'); amount.textContent = money(value); caption.append(name, amount);
      const track = document.createElement('div'); track.className = 'chart-track'; const bar = document.createElement('span'); bar.style.width = `${value / ceiling * 100}%`; track.append(bar); row.append(caption, track); chart.append(row);
    }
    box.append(chart);
    add('p', `Puesto objetivo: ${field('role').value}. ${field('move').value}.`);
    add('p', `Importes ${field('basis').value === 'gross' ? 'brutos' : 'netos'}.`);
    if (regionalMode || field('currency').value !== field('output').value) add('p', `Conversión ingresada por vos: 1 USD = ${conversionRate} ${unit}. Fecha: ${field('rateDate').value}. Fuente: ${field('rateSource').value}.`);
    if (result.gap === 0) add('p', 'Tu ingreso actual alcanza o supera tu objetivo. Con estos datos no hay una brecha positiva.');
    if (market.available) {
      add('h3', market.regional ? market.source.title : 'Referencia publicada para tu puesto');
      if (market.regional) {
        add('p', `Cambio por USD: ARS ${market.fx.rates.ARS}, COP ${market.fx.rates.COP}, MXN ${market.fx.rates.MXN}. ${market.fx.provider} · ${market.fx.updatedAt}.`);
        add('p', `Promedio de puntos medios: ${money(market.amount)} / mes. Cobertura: ${market.countries.length} de 3 países.`);
        for (const row of market.countries) { add('p', `${row.country}: ${money(row.low)} – ${money(row.high)}; punto medio ${money(row.midpoint)} (${row.variants} variantes).`); add('p', `${row.references[0].source.publisher} · ${row.references[0].source.title} · ${[...new Set(row.references.map(ref => ref.page ? 'p. ' + ref.page : ref.source.published))].join(', ')}`); }
        if (market.missing.length) add('p', `Faltan datos comparables de ${market.missing.join(', ')}. Este resultado NO es un promedio de tres países.`);
      }
      add('p', `${market.reference.role}: ${marketValue(market, 'amount', money)}. ${market.source.scope}.`);
      add('p', `Brecha con esta referencia: ${marketValue(market, 'gap', money)} / mes. Escenario durante tu búsqueda: ${marketValue(market, 'opportunity', money)}.`);
      add('p', 'Este escenario y el de tu objetivo personal son alternativas; no se suman.');
      const details = document.createElement('details'); const summary = document.createElement('summary'); summary.textContent = 'Cómo interpretar esta referencia +';
      const description = document.createElement('p'); description.textContent = market.source.methodology; details.append(summary, description); box.append(details);
      add('p', `${market.source.publisher} · ${market.source.title} · ${market.source.published}${market.source.page ? ` · página ${market.source.page}` : ''}.`);
      if (market.source.url) { const link = document.createElement('a'); link.href = market.source.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = `Ver fuente · ${market.source.publisher}`; box.append(link); }
      else add('p', 'Fuente: PDF aportado por el usuario. No se publica el documento completo.');
      add('p', 'Comparación nominal con la edición indicada: sin ajuste por inflación. No afirma cuánto ganarías hoy ni reconstruye tus ingresos pasados.');
    } else add('p', `Referencia de mercado no disponible: ${market.reason}`);
    add('p', 'El resultado personal usa tus importes y meses. La experiencia y el tipo de salto no aplican aumentos automáticos.');
    add('p', 'Es una estimación de oportunidad bajo tus supuestos, no dinero perdido comprobado ni una promesa de salario o contratación.');
    const report = buildReport({ result, market, role: field('role').value, movement: field('move').value, experience: field('experience').value, country: countries.find(([code]) => code === field('country').value)[1], targetCountry: countries.find(([code]) => code === field('targetCountry').value)[1], basis: field('basis').value === 'gross' ? 'Brutos' : 'Netos', months: Number(field('months').value), date: new Intl.DateTimeFormat('es-AR').format(new Date()), exchange: (regionalMode || field('currency').value !== field('output').value) ? `1 USD = ${conversionRate} ${unit}; fecha ${field('rateDate').value}; fuente ${field('rateSource').value}` : '' });
    const download = document.createElement('button'); download.type = 'button'; download.textContent = 'Descargar mi informe'; download.addEventListener('click', () => {
      const url = URL.createObjectURL(new Blob([report], {type:'text/html;charset=utf-8'}));
      const link = document.createElement('a'); link.href = url; link.download = 'mi-informe-salarial-insertarte.html'; document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    }); box.append(download);
    const print = document.createElement('button'); print.type = 'button'; print.textContent = 'Guardar o imprimir mi resultado'; print.addEventListener('click', () => window.print()); box.append(print);
    document.querySelector('#error').textContent = '';
    box.focus({ preventScroll: true });
    box.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block: 'start' });
  } catch (error) { document.querySelector('#error').textContent = error.message; }
});
setCurrencies();

filterReferences();
setupFlow();

const fxReady = loadFx().then(data => { activeFx=data; updateExchange(); return data; }).catch(error => { fxFailure=error.message; updateExchange(); return null; });
