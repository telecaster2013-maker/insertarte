import {countries} from './calculator.js';
import {loadFx} from './fx.js';
import {suggestions,levelOf,estimateSalary,whatsappLink} from './lead-model.js';
const form=document.querySelector('#salary-form'),field=n=>form.elements.namedItem(n);
const sections=[...form.querySelectorAll('[data-step]')];
const options=document.querySelector('#role-options'),roleInput=field('role');
let step=0,selectedId='',items=[],activeOption=-1,working=false;
const fxReady=loadFx().then(fx=>({fx})).catch(error=>({error}));
for(const [code,name] of countries)field('country').add(new Option(name,code));
for(const name of ['currency','output'])for(const c of [...new Set(['USD',...countries.map(c=>c[2])])])field(name).add(new Option(c,c));
function showStep(n,focus=true){step=n;sections.forEach((s,i)=>s.hidden=i!==n);for(let i=0;i<2;i++){const tab=document.querySelector('#tab-'+i);tab.classList.toggle('active',i===n);tab.classList.toggle('done',i<n);if(i===n)tab.setAttribute('aria-current','step');else tab.removeAttribute('aria-current');}document.querySelector('#form-error').textContent='';if(focus){const title=sections[n].querySelector('h3');title.tabIndex=-1;title.focus({preventScroll:true});document.querySelector('#chequeo').scrollIntoView({behavior:'instant',block:'start'});}}
function validate(n){const invalid=[...sections[n].querySelectorAll('input,select')].find(e=>!e.checkValidity());if(invalid){invalid.reportValidity();return false;}return true;}
document.querySelector('#next').addEventListener('click',()=>{if(validate(0)){closeOptions();showStep(1);}});
document.querySelector('#back').addEventListener('click',()=>showStep(0));
field('country').addEventListener('change',()=>{const country=countries.find(c=>c[0]===field('country').value);field('currency').value=country?.[2]||'USD';field('output').value=field('currency').value;});
field('currency').addEventListener('change',()=>field('output').value=field('currency').value);
function closeOptions(){options.hidden=true;roleInput.setAttribute('aria-expanded','false');roleInput.removeAttribute('aria-activedescendant');activeOption=-1;}
function choose(i){const item=items[i];if(!item)return;selectedId=item.id;roleInput.value=item.title;field('level').value=item.level;document.querySelector('#role-hint').textContent='Puesto reconocido. Podés ajustar tu nivel si lo necesitás.';closeOptions();roleInput.focus({preventScroll:true});}
function showOptions(){items=suggestions(roleInput.value);options.replaceChildren();activeOption=-1;if(!items.length){closeOptions();document.querySelector('#role-hint').textContent=roleInput.value.length>1?'Podés seguir con tu puesto: estimaremos una referencia por tu nivel de responsabilidad.':'Escribí tu puesto y elegí la opción que mejor lo describe.';return;}items.forEach((item,i)=>{const el=document.createElement('button');el.type='button';el.tabIndex=-1;el.role='option';el.id='role-option-'+i;const title=document.createElement('strong');title.textContent=item.title;const sector=document.createElement('span');sector.textContent=item.sector||'Referencia de mercado';el.append(title,sector);el.addEventListener('click',()=>choose(i));options.append(el);});options.hidden=false;roleInput.setAttribute('aria-expanded','true');}
roleInput.addEventListener('input',()=>{selectedId='';const level=levelOf(roleInput.value);if(level!=='professional')field('level').value=level;showOptions();});
roleInput.addEventListener('focus',()=>{if(roleInput.value.length>1&&!selectedId)showOptions();});
roleInput.addEventListener('keydown',event=>{if(event.key==='Escape'){closeOptions();return;}if(!options.hidden&&['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();activeOption=activeOption<0?(event.key==='ArrowDown'?0:items.length-1):(activeOption+(event.key==='ArrowDown'?1:-1)+items.length)%items.length;[...options.children].forEach((el,i)=>el.setAttribute('aria-selected',String(i===activeOption)));roleInput.setAttribute('aria-activedescendant','role-option-'+activeOption);options.children[activeOption].scrollIntoView({block:'nearest'});}if(event.key==='Enter'&&!options.hidden){event.preventDefault();choose(activeOption>=0?activeOption:0);}});
document.addEventListener('click',e=>{if(!e.target.closest('.role-field'))closeOptions();});
field('level').addEventListener('change',()=>{selectedId='';});
form.addEventListener('submit',async event=>{
 event.preventDefault();if(working)return;if(step===0){if(validate(0)){closeOptions();showStep(1);}return;}if(!validate(0)){showStep(0);validate(0);return;}if(!validate(1))return;
 const input={role:roleInput.value.trim(),referenceId:selectedId,level:field('level').value,country:field('country').value,salary:Number(field('salary').value),currency:field('currency').value,output:field('output').value};
 working=true;const button=document.querySelector('#calculate');button.disabled=true;document.querySelector('#back').disabled=true;button.textContent='Estamos calculando…';document.querySelector('#form-error').textContent='';
 try{const {fx,error}=await fxReady;if(error)throw error;const result=estimateSalary({...input,fx});renderResult(result,input);}catch(error){renderResult({available:false,reason:'No pudimos obtener una estimación confiable en este momento. Podemos conversar sobre tu perfil y tu próximo paso.'},input);}finally{working=false;button.disabled=false;document.querySelector('#back').disabled=false;button.textContent='Ver mi resultado ↗';}
});
function money(value,currency){return currency+' '+new Intl.NumberFormat('es-AR',{maximumFractionDigits:0}).format(value);}
function node(tag,text,cls){const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(cls)el.className=cls;return el;}
function renderResult(result,input){
 const panel=document.querySelector('#result');panel.replaceChildren();const head=node('div',undefined,'result-top');head.append(node('span','TU CHEQUEO SALARIAL','eyebrow'),node('span','Tu oportunidad salarial, en números.','result-top-note'));panel.append(head);
 const body=node('div',undefined,'result-body'),numbers=node('div',undefined,'result-numbers');
 if(result.available){
  const displayedGap=Math.max(0,Math.round(result.estimated)-Math.round(result.current));
  const displayedAnnual=displayedGap*12;
  const titles={below:'Tu sueldo podría estar quedándose corto.',within:'Tu sueldo está dentro del rango estimado.',above:'Tu sueldo supera nuestra referencia.'};numbers.append(node('h2',displayedGap>0?'Todos los meses estás dejando sobre la mesa:':titles[result.position]));
  if(displayedGap>0){
    const opportunity=node('div',undefined,'opportunity spotlight');
    opportunity.append(node('p','Brecha estimada frente a la referencia de tu perfil','opportunity-context'));
    const amounts=node('div',undefined,'opportunity-amounts');
    for(const [period,value,cls] of [['por mes',displayedGap,'monthly'],['por año',displayedAnnual,'yearly']]){
      const card=node('div',undefined,'opportunity-card '+cls);
      const formatted=new Intl.NumberFormat('es-AR',{maximumFractionDigits:0}).format(value);
      card.append(node('span',result.currency,'opportunity-currency'),node('strong',formatted,'opportunity-value'+(formatted.length>10?' money-long':'')),node('span',period,'opportunity-period'));
      amounts.append(card);
    }
    opportunity.append(amounts,node('p','Montos redondeados. Es una oportunidad estimada si alcanzaras esa referencia, no dinero perdido comprobado.','opportunity-note'));numbers.append(opportunity);
  }
  if(result.basis==='level-estimate')numbers.append(node('p','Estimación orientativa por nivel de responsabilidad. Agrupa distintos puestos; no es una banda específica del tuyo.','estimate-note'));
  const pair=node('div',undefined,'salary-comparison');for(const [label,value,cls]of[['Tu sueldo actual',result.current,'current'],[result.basis==='level-estimate'?'Estimación por nivel':'Referencia estimada',result.estimated,'market']]){const item=node('div',undefined,cls);item.append(node('span',label),node('strong',money(value,result.currency)),node('small','por mes · bruto'));pair.append(item);}numbers.append(pair);
  const chart=node('div',undefined,'comparison-chart');const ceiling=Math.max(result.current,result.estimated,1);for(const[label,value]of[['Tu sueldo',result.current],['Referencia',result.estimated]]){const line=node('div');line.append(node('span',label));const track=node('div',undefined,'chart-track');const bar=node('i');bar.style.setProperty('--bar-width',`${value/ceiling*100}%`);track.append(bar);line.append(track);chart.append(line);}numbers.append(chart);
  if(displayedGap===0)numbers.append(node('p','Tu próximo salto también puede estar en la responsabilidad, las condiciones o la proyección de tu carrera.','positive-note'));
  const coverage=result.basis==='level-estimate'?`Base orientativa · ${result.coverage} países · distintos puestos del mismo nivel`:result.regional?`Referencia regional · ${result.coverage} de 3 países comparables${result.missing.length?' · cobertura parcial':''}`:'Referencia del mercado elegido';numbers.append(node('p',coverage,'coverage'));
  const details=node('details',undefined,'result-details');details.append(node('summary','Cómo leer esta estimación +'));const text=node('div');text.append(node('p',result.explanation));text.append(node('p',`Rango orientativo: ${money(result.low,result.currency)} – ${money(result.high,result.currency)} brutos mensuales. El valor central es un promedio de puntos medios, no una oferta garantizada.`));for(const country of result.market.countries){const sources=[...new Set(country.references.map(ref=>`${ref.source.publisher}, ${ref.source.published}${ref.page?', p. '+ref.page:''}`))];text.append(node('p',`${country.country}: ${sources.join(' · ')}.`));}text.append(node('p',`Cambio: ${result.market.fx.provider}, ${result.market.fx.updatedAt}. ${result.market.fx.origin}. No ajusta por inflación, beneficios ni diferencias contractuales.`));if(result.missing.length)text.append(node('p',`Sin referencias comparables de ${result.missing.join(', ')} para este puesto. No es un promedio de los tres países.`));details.append(text);numbers.append(details);
 }else{numbers.append(node('h2','Tu perfil merece una mirada más específica.'),node('p',result.reason,'unavailable-copy'),node('p','Que falte una referencia no dice nada sobre tu valor. La conversación puede empezar por tu experiencia y lo que querés construir.','unavailable-copy'));}
 const cta=node('div',undefined,'result-cta');cta.append(node('span','EL NÚMERO ES EL COMIENZO.','form-kicker'),node('h3',result.available&&result.gap>0?'¿Qué necesitás cambiar para dar ese salto?':'¿Conversamos sobre tu próximo capítulo?'),node('p','Conversemos sobre tu experiencia, cómo te estás posicionando y qué puede estar frenando tu próximo paso.'));const link=node('a','Quiero mi diagnóstico por WhatsApp','btn btn-primary whatsapp-cta');link.href=whatsappLink({result,...input});link.target='_blank';link.rel='noopener noreferrer';cta.append(link,node('small','Se abre un mensaje editable con tu resultado. Vos decidís enviarlo.'));body.append(numbers,cta);panel.append(body);
 const foot=node('div',undefined,'result-bottom');const edit=node('button','Cambiar mis datos','btn btn-back');edit.type='button';edit.addEventListener('click',()=>{panel.hidden=true;document.querySelector('#check-shell').hidden=false;showStep(0);});foot.append(edit,node('p','Estimación orientativa, no una pérdida comprobada ni una promesa de salario.'));panel.append(foot);document.querySelector('#check-shell').hidden=true;panel.hidden=false;panel.focus({preventScroll:true});panel.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});
}
// Motion is decorative, can be paused, and respects the device accessibility setting.
const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');let paused=reduced.matches;
const motionButton=document.querySelector('#motion-toggle');function applyMotion(){document.body.classList.toggle('motion-paused',paused||reduced.matches);motionButton.setAttribute('aria-pressed',String(paused||reduced.matches));motionButton.disabled=reduced.matches;motionButton.setAttribute('aria-label',reduced.matches?'Animaciones desactivadas según tu dispositivo':paused?'Activar animaciones':'Pausar animaciones');}
motionButton.addEventListener('click',()=>{paused=!paused;applyMotion();});reduced.addEventListener('change',applyMotion);applyMotion();
if('IntersectionObserver'in window){const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{entry.target.classList.toggle('in-view',entry.isIntersecting);}),{threshold:.08});document.querySelectorAll('[data-motion],[data-reveal]').forEach(el=>observer.observe(el));}
showStep(0,false);
