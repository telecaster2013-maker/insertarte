import {roleKey} from './matching.js';
import {referenceSource} from './salary-data.js';
import {validateFx} from './fx.js';
// Broad benchmark: equal weight per job family within country, then per country.
// This is explicitly not a verified salary band for the visitor's exact occupation.
export function fallbackMarket({level,levelOf,country,regional,fx,rows,now=Date.now()}) {
 validateFx(fx,now);
 let pool=rows.filter(r=>r.basis==='gross'&&levelOf(r.role)===level);
 let localOnly=!regional;
 if(localOnly&&pool.some(r=>r.country===country))pool=pool.filter(r=>r.country===country);
 else localOnly=false;
 if(!pool.length)return {available:false,reason:'No hay datos suficientes para este nivel de responsabilidad.'};
 const countries=[];
 for(const code of ['AR','CO','MX']){
  const national=pool.filter(r=>r.country===code);if(!national.length)continue;
  const groups=new Map();
  for(const row of national){const key=roleKey(row.role)+'|'+(row.sector||'');if(!groups.has(key))groups.set(key,[]);groups.get(key).push(row);}
  const bands=[];
  for(const group of groups.values()){
   const low=group.reduce((sum,r)=>sum+(r.low??r.amount)/fx.rates[r.currency],0)/group.length;
   const high=group.reduce((sum,r)=>sum+(r.high??r.amount)/fx.rates[r.currency],0)/group.length;
   bands.push({low,high});
  }
  const low=bands.reduce((s,b)=>s+b.low,0)/bands.length,high=bands.reduce((s,b)=>s+b.high,0)/bands.length;
  const refs=new Map();for(const r of national){if(!Number.isFinite(fx.rates[r.currency])||fx.rates[r.currency]<=0)throw new Error('Cotización no válida.');const source=referenceSource(r);const key=source.publisher+'|'+source.title;if(!refs.has(key))refs.set(key,{role:`Referencias agregadas del nivel seleccionado (${groups.size} familias de puestos)`,page:null,source});}
  countries.push({country:code,low,high,midpoint:(low+high)/2,positions:groups.size,variants:national.length,references:[...refs.values()]});
 }
 const low=countries.reduce((s,c)=>s+c.low,0)/countries.length,high=countries.reduce((s,c)=>s+c.high,0)/countries.length;
 if(![low,high].every(Number.isFinite))throw new Error('No se pudo normalizar la estimación.');
 return {available:true,regional:!localOnly,kind:'range',low,high,amount:(low+high)/2,countries,fx,missing:['AR','CO','MX'].filter(code=>!countries.some(c=>c.country===code)),source:{methodology:(!regional&&!localOnly?`No hay referencia local para ${country}; se proyecta una referencia regional a la moneda elegida. `:'')+'Estimación orientativa agregada por nivel de responsabilidad, mezclando distintos puestos. Cada familia tiene igual peso dentro de su país y luego cada país tiene igual peso. No es una banda verificada para el puesto exacto.',publisher:'Referencias agregadas de las guías disponibles'}};
}
